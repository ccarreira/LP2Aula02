﻿using System;

namespace ClassVsStruct
{
    public class Program
    {
        private static void Main(string[] args)
        {

            Player player_01;
            Player player_02;

            //player_01 = new Player(health: 130, armor: 10);
            player_01 = new Player
            {
                Health = 130,
                Armor = 10
            };

            player_02 = player_01;

            Console.WriteLine("Player 01 Health: " + player_01.Health);
            Console.WriteLine("Player 01 Armor: " + player_01.Armor);

            Console.WriteLine("Player 02 Health: " + player_02.Health);
            Console.WriteLine("Player 02 Armor: " + player_02.Armor);

            player_01.Health = 10;
            player_01.Armor = 0;

            Console.WriteLine("***********************");
            Console.WriteLine("Player 01 Health: " + player_01.Health);
            Console.WriteLine("Player 01 Armor: " + player_01.Armor);

            Console.WriteLine("Player 02 Health: " + player_02.Health);
            Console.WriteLine("Player 02 Armor: " + player_02.Armor);

        }
    }
}
